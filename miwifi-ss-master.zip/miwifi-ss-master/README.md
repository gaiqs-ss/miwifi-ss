# WHAT
小米路由器 shadowsocks 插件
# USAGE
cd /tmp && rm -rf *.sh && curl https://raw.githubusercontent.com/blademainer/miwifi-ss/master/miwifi.sh -o miwifi.sh && chmod +x miwifi.sh && sh ./miwifi.sh && rm -rf *.sh
