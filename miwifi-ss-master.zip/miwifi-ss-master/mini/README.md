`ss-redir` from [shadowsocks-libev_3.2.4-1_mipsel_24kc.ipk](https://dl.bintray.com/aa65535/opkg/shadowsocks-libev/3.2.4-1/current/mipsel_24kc/)


用 7z 解压 shadowsocks-libev_3.2.4-1_mipsel_24kc.ipk, 获得 `data.tar.gz` 继续解压，获得 `ss-redir`
